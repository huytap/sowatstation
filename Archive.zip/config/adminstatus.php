<?php
return [
    'Publish',
    'Unpublish'
];
