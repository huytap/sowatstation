<?php
namespace App\Helpers;
class Enum
{
    const SHOW = 0;
    const HIDE = 1;
    const UPLOAD_FOLDER_NAME = '/public/uploads';
    const SOWATER = 0;
    const ARTIST = 1;
    const ALL = 2;
    const PROJECT = 2;
    const EVENT = 0;
    const PRODUCT = 3;
}
