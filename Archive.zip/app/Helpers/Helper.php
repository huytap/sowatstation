<?php

namespace App\Helpers;

class Helper
{
    public static function getListMenu()
    {
    }
}
